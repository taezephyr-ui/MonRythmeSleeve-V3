const fs=require('fs');const assert=require('assert/strict');
const src=fs.readFileSync('V3/app/src/main/java/fr/monrythmesleeve/app/ScheduleStore.java','utf8');
function extract(name){let m=new RegExp('public static String '+name+'\\([^)]*\\)\\{').exec(src);assert(m);let i=m.index+m[0].length,start=i,d=1;while(d){if(src[i]==='{')d++;if(src[i]==='}')d--;i++;}return src.slice(start,i-1);}
let body=extract('correctFinish').replace(/\bHistoryStore\.Entry\b/g,'let').replace(/SharedPreferences\.Editor/g,'let').replace(/int\[\]/g,'let').replace(/\b(?:boolean|int)\b/g,'let').replace(/try\(HistoryStore db=new HistoryStore\(c\)\)\{/g,'{let db=new HistoryStore(c);').replace(/System\.currentTimeMillis\(\)/g,'NOW').replace(/(\d[\d_]*)L\b/g,'$1');
const NOW=10*86400000+12*3600000,MEAL_DURATION=30;let current=10;
class Day{constructor(n){this.n=n;}equals(o){return this.n===o.n;}toString(){return String(this.n);}}
const day=c=>new Day(current),gap=c=>150,count=c=>6,name=i=>'Meal '+i,at=(d,m)=>(d.n*1440+m)*60000,ceilMinuteOf=(d,t)=>Math.ceil((t-d.n*86400000)/60000),timesFor=(c,d)=>c.times.slice(),record=(c,d,i)=>c.records.get(d+':'+i)||null;
class HistoryStore{constructor(c){this.c=c;}finish(d,i,title,planned,finished){const k=d+':'+i,r=this.c.records.get(k)||{planned,started:0};this.c.records.set(k,{...r,finished});}}
function prefs(c){return {edit(){let changes=[];return {putInt(key,v){changes.push([Number(key.split('_').pop()),v]);return this;},apply(){for(let [i,v] of changes)c.times[i]=v;}};}};}
const correctFinish=new Function('c','d','index','actual','record','at','day','timesFor','HistoryStore','prefs','ceilMinuteOf','gap','count','name','NOW','MEAL_DURATION',body);
const run=(c,d,i,actual)=>correctFinish(c,d,i,actual,record,at,day,timesFor,HistoryStore,prefs,ceilMinuteOf,gap,count,name,NOW,MEAL_DURATION);
const fresh=()=>({records:new Map(),times:[0,180,360,540,720,900]});let checks=0;
function ok(fn){fn();checks++;}
const d=new Day(10),start=at(d,0)+1000;let c=fresh();c.records.set('10:0',{planned:start,started:start,finished:start+1000});
ok(()=>assert.equal(run(c,d,0,start+60000),null));ok(()=>assert.equal(c.times[1],152));ok(()=>assert.equal(c.times[2],332));ok(()=>assert.equal(record(c,d,0).started,start));ok(()=>assert.equal(record(c,d,0).finished,start+60000));
ok(()=>assert.notEqual(run(c,d,0,start-1),null));ok(()=>assert.notEqual(run(c,d,0,NOW+1),null));ok(()=>assert.equal(record(c,d,0).finished,start+60000));
c=fresh();c.records.set('10:0',{planned:start,started:start,finished:start+1000});c.records.set('10:2',{planned:start+6000,started:start+6000,finished:start+7000});
ok(()=>assert.equal(run(c,d,0,start+2000),null));ok(()=>assert.equal(c.times[2],360));ok(()=>assert.equal(c.times[3],540));ok(()=>assert.equal(record(c,d,2).finished,start+7000));ok(()=>assert.notEqual(run(c,d,0,start+6500),null));
c=fresh();let previous=new Day(9),end=at(previous,1470);c.records.set('9:5',{planned:end-1800000,started:0,finished:end});let before=c.times.slice();
ok(()=>assert.equal(run(c,previous,5,end+60000),null));ok(()=>assert.deepEqual(c.times,before));ok(()=>assert.equal(record(c,previous,5).started,0));ok(()=>assert.equal(record(c,previous,5).finished,end+60000));
c=fresh();ok(()=>assert.equal(run(c,d,0,start+60000),null));ok(()=>assert.equal(record(c,d,0).started,0));ok(()=>assert.notEqual(run(c,d,-1,start),null));ok(()=>assert.notEqual(run(c,d,6,start),null));
console.log(checks+' assertions réussies sur correctFinish extrait du Java, avec stockage et horloge simulés. Ce contrôle ne remplace pas les tests Android.');
