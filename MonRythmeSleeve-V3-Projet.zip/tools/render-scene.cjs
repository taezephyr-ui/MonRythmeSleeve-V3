// Local visual QA and assets: executes the Java room / animal drawing methods in WebGL.
// Geometry, colours and shaders are read directly from RoomRenderer.java.
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
const source=fs.readFileSync(path.join(root,'app/src/main/java/fr/monrythmesleeve/app/RoomRenderer.java'),'utf8');
function method(name){
 const match=new RegExp('private void '+name+'\\(([^)]*)\\)\\{').exec(source);
 if(!match)throw Error(name);
 let end=match.index+match[0].length,depth=1,start=end;
 while(depth){let ch=source[end++];if(ch==='{')depth++;if(ch==='}')depth--;}
 let body=source.slice(start,end-1).replace(/\(float\)/g,'').replace(/\b(?:float|int|boolean)\b/g,'let').replace(/(\d+(?:\.\d*)?|\.\d+)f\b/g,'$1');
 return `function ${name}(${match[1].split(',').map(p=>p.trim().split(' ').pop()).join(',')}){${body}}`;
}
const methods=['room','glass','flower','star','part','animal','wear'].map(method).join('\n');
const vertex=JSON.parse(source.match(/String VERTEX=("[^\n]*");/)[1]);
const fragment=JSON.parse(source.match(/String FRAGMENT=("[^\n]*");/)[1]);
const runtime=`
const canvas=document.querySelector('canvas'),gl=canvas.getContext('webgl',{preserveDrawingBuffer:true,antialias:true});
if(!gl)throw Error('WebGL unavailable');
const shader=(type,src)=>{let s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;};
const program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,${JSON.stringify(vertex)}));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,${JSON.stringify(fragment)}));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);gl.enable(gl.DEPTH_TEST);
const attr={p:gl.getAttribLocation(program,'aPos'),n:gl.getAttribLocation(program,'aNorm')};
const uniform={};for(let key of ['uMVP','uModel','uNormal','uColor','uTexture'])uniform[key]=gl.getUniformLocation(program,key);
function identity(){return [1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];}
function mul(a,b){let r=Array(16).fill(0);for(let c=0;c<4;c++)for(let row=0;row<4;row++)for(let k=0;k<4;k++)r[c*4+row]+=a[k*4+row]*b[c*4+k];return r;}
function rotate(deg,axis){let a=deg*Math.PI/180,c=Math.cos(a),s=Math.sin(a),r=identity();if(axis===0){r[5]=c;r[6]=s;r[9]=-s;r[10]=c;}if(axis===1){r[0]=c;r[2]=-s;r[8]=s;r[10]=c;}if(axis===2){r[0]=c;r[1]=s;r[4]=-s;r[5]=c;}return r;}
function lookAt(eye,target){let norm=v=>{let n=Math.hypot(...v);return v.map(x=>x/n);},cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],dot=(a,b)=>a.reduce((n,x,i)=>n+x*b[i],0),z=norm(eye.map((x,i)=>x-target[i])),x=norm(cross([0,1,0],z)),y=cross(z,x);return [x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1];}
function ortho(l,r,b,t,n,f){return [2/(r-l),0,0,0,0,2/(t-b),0,0,0,0,-2/(f-n),0,-(r+l)/(r-l),-(t+b)/(t-b),-(f+n)/(f-n),1];}
function mesh(data){let b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);return {b,count:data.length/6};}
const sphere=(()=>{let a=[];for(let j=0;j<12;j++)for(let i=0;i<18;i++){let dx=[0,1,1,0,1,0],dy=[0,0,1,0,1,1];for(let k=0;k<6;k++){let u=(i+dx[k])*Math.PI*2/18,v=(j+dy[k])*Math.PI/12,x=Math.sin(v)*Math.cos(u),y=Math.cos(v),z=Math.sin(v)*Math.sin(u);a.push(x,y,z,x,y,z);}}return mesh(a);})();
const cube=(()=>{let a=[];for(let axis=0;axis<3;axis++)for(let side of [-1,1]){let u=[-1,1,1,-1,1,-1],v=[-1,-1,1,-1,1,1];for(let k=0;k<6;k++){let p=[0,0,0],n=[0,0,0];p[axis]=side;p[(axis+1)%3]=u[k];p[(axis+2)%3]=v[k];n[axis]=side;a.push(...p,...n);}}return mesh(a);})();
const cylinder=(()=>{let a=[];for(let i=0;i<24;i++){let x=Math.cos(i*Math.PI*2/24),z=Math.sin(i*Math.PI*2/24),xx=Math.cos((i+1)*Math.PI*2/24),zz=Math.sin((i+1)*Math.PI*2/24);a.push(x,-1,z,x,0,z,xx,-1,zz,xx,0,zz,xx,1,zz,xx,0,zz,x,-1,z,x,0,z,xx,1,zz,xx,0,zz,x,1,z,x,0,z);for(let s of [-1,1])a.push(0,s,0,0,s,0,x,s,z,0,s,0,xx,s,zz,0,s,0);}return mesh(a);})();
let vp=identity(),time=1.7,petX=.4,petZ=.6,facing=0,baseY=0,angle=0,breath=1,material=0,species=0,decor=-1,accessory=-1,motion=true;
const CREAM=0xFFF9E8CC,WOOD=0xFFB97F52,WHITE=0xFFFFFAF1,DARK=0xFF342C44,PINK=0xFFE8A0B9;
const FUR=[0xFFA58CDD,0xFFF2AABB,0xFFA97F61,0xFFB5BDD2,0xFFCD7543,0xFFF2B3CC,0xFFE8D7BC,0xFFBA9874],TINTS=[0xFFD78FAD,0xFF8D9EC7,0xFF76B5BC,0xFF8FAF8A,0xFFDDB26D,0xFFB69AC8];
Math.toRadians=n=>n*Math.PI/180;
function draw(mesh,x,y,z,sx,sy,sz,color,texture,rx,ry,rz){let m=identity();m[12]=x;m[13]=y;m[14]=z;m=mul(m,rotate(ry,1));m=mul(m,rotate(rx,0));m=mul(m,rotate(rz,2));let s=identity();s[0]=sx;s[5]=sy;s[10]=sz;m=mul(m,s);let n=m.slice();for(let col=0;col<3;col++){let len=n[col*4]**2+n[col*4+1]**2+n[col*4+2]**2;for(let row=0;row<3;row++)n[col*4+row]/=len;}n[12]=n[13]=n[14]=0;gl.uniformMatrix4fv(uniform.uMVP,false,mul(vp,m));gl.uniformMatrix4fv(uniform.uModel,false,m);gl.uniformMatrix4fv(uniform.uNormal,false,n);gl.uniform3f(uniform.uColor,((color>>>16)&255)/255,((color>>>8)&255)/255,(color&255)/255);gl.uniform1f(uniform.uTexture,texture);gl.bindBuffer(gl.ARRAY_BUFFER,mesh.b);gl.vertexAttribPointer(attr.p,3,gl.FLOAT,false,24,0);gl.vertexAttribPointer(attr.n,3,gl.FLOAT,false,24,12);gl.enableVertexAttribArray(attr.p);gl.enableVertexAttribArray(attr.n);gl.drawArrays(gl.TRIANGLES,0,mesh.count);}
function ball(x,y,z,a,b,c,col){draw(sphere,x,y,z,a,b,c,col,0,0,0,0);}
function box(x,y,z,a,b,c,col,tex){draw(cube,x,y,z,a,b,c,col,tex,0,0,0);}
function disk(x,y,z,r,h,col){draw(cylinder,x,y,z,r,h,r,col,0,0,0,0);}
${methods}
window.renderScene=(opts={})=>{species=opts.species??0;decor=opts.decor??-1;accessory=opts.accessory??-1;time=opts.time??1.7;motion=opts.motion??true;let state=opts.pose??0,portrait=opts.portrait??false;gl.viewport(0,0,512,512);gl.clearColor(.94,.90,.87,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);petX=portrait?0:state===1||state===2?-1.15:state===5?1.65:.4;petZ=portrait?0:state===1||state===2?-.82:state===5?-1.1:.6;facing=state===1||state===2?0:15;vp=portrait?mul(ortho(-1.6,1.6,-1.6,1.6,1,40),lookAt([2.8,2.4,8],[0,1.25,0])):mul(ortho(-4.2,4.2,-4.2,4.2,1,40),lookAt([7,6.8,10],[0,.8,0]));if(!portrait)room();animal(state);gl.finish();if(gl.getError()!==gl.NO_ERROR)throw Error('WebGL draw error');};
window.renderScene();
`;
fs.mkdirSync(path.join(root,'qa'),{recursive:true});
fs.writeFileSync(path.join(root,'qa/scene.html'),`<!doctype html><html><meta charset="utf-8"><style>html,body{margin:0;background:#f0e6de}canvas{width:512px;height:512px;display:block}</style><canvas width="512" height="512"></canvas><script>${runtime}</script></html>`);
async function main(){
 const {chromium}=require('playwright');
 const browser=await chromium.launch({headless:true,channel:'chrome',args:['--enable-webgl','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:512,height:512},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('file:///'+path.join(root,'qa/scene.html').replaceAll('\\','/'));
 if(errors.length)throw Error(errors.join('\n'));
 for(let species=0;species<8;species++){
  await page.evaluate(o=>window.renderScene(o),{species,portrait:true});
  await page.screenshot({path:path.join(root,`app/src/main/res/drawable-nodpi/companion_${species}.png`)});
 }
 for(let item=0;item<6;item++){
  await page.evaluate(o=>window.renderScene(o),{species:0,portrait:true,accessory:item});
  await page.screenshot({path:path.join(root,`app/src/main/res/drawable-nodpi/reward_accessory_${item}.png`)});
 }
 for(let decor=0;decor<4;decor++){
  await page.evaluate(o=>window.renderScene(o),{decor});
  await page.screenshot({path:path.join(root,`app/src/main/res/drawable-nodpi/reward_decor_${decor}.png`)});
 }
 for(let pose=0;pose<6;pose++){
  await page.evaluate(o=>window.renderScene(o),{pose});await page.screenshot({path:path.join(root,`qa/pose_${pose}.png`)});
 }
 console.log(JSON.stringify({rendered:24,errors}));await browser.close();
}
main().catch(e=>{console.error(e);process.exit(1);});
