const fs=require('fs'),path=require('path'),assert=require('assert/strict');const root='V3/app/src/main';
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)]);
const files=walk(root),java=files.filter(f=>f.endsWith('.java'));let refs=0;
for(const file of java){const s=fs.readFileSync(file,'utf8');
 for(const m of s.matchAll(/\bR\.(drawable|mipmap|color)\.(\w+)/g)){
   if(s.slice(Math.max(0,m.index-8),m.index).endsWith('android.'))continue;
   refs++;assert(m[1]==='color'?fs.readFileSync(root+'/res/values/colors.xml','utf8').includes('name="'+m[2]+'"'):files.some(f=>path.basename(f).split('.')[0]===m[2]),file+': missing '+m[0]);
 }
 // Balance Java delimiters after masking comments, quoted strings and char literals.
 const code=s.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g,'');const stack=[],pairs={')':'(',']':'[','}':'{'};
 for(const ch of code){if('([{'.includes(ch))stack.push(ch);else if(')]}'.includes(ch))assert.equal(stack.pop(),pairs[ch],file+' delimiters');}assert.equal(stack.length,0,file+' unclosed');
}
const main=fs.readFileSync(root+'/java/fr/monrythmesleeve/app/MainActivity.java','utf8');assert(!/Collation 6|6e collation|pet_atlas/.test(java.map(f=>fs.readFileSync(f,'utf8')).join('')));
assert(main.includes('CompanionIcon.apply(this,species)'));assert(main.includes('setForeground(false)'));assert(main.includes('Typeface.BOLD:Typeface.NORMAL'));
const manifest=fs.readFileSync(root+'/AndroidManifest.xml','utf8');assert.equal((manifest.match(/<activity-alias/g)||[]).length,9);assert.equal((manifest.match(/android:enabled="true"/g)||[]).length,1);
console.log(java.length+' fichiers Java contrôlés (délimiteurs et ressources), '+refs+' références de ressources résolues ; 9 alias avec un seul actif par défaut. Ce contrôle ne remplace pas javac/Android.');
