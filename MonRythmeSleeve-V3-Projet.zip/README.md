# Mon Rythme Sleeve — V3 bêta

Projet Android natif basé sur la V2.1 Compagnons. L'application fonctionne sans connexion et conserve les mêmes noms de préférences et de base d'historique. Le projet d'origine sur le Bureau n'a pas été remplacé.

## Changements

- Bouton **Modifier l'heure de fin** dans l'accueil, le planning et l'historique. Choix de la date du planning ou du lendemain, puis de l'heure. La correction garde le début réel et les autres prises enregistrées ; les prises suivantes encore prévues et les alarmes sont recalculées. Une correction dans une ancienne journée ne change pas le planning actuel.
- **Collation 3** remplace Collation 6. Il s'agit toujours de la sixième prise facultative, après le dîner, éventuellement après minuit.
- Dans le sélecteur de référence, petit-déjeuner, déjeuner et dîner apparaissent en gras, avec une taille et un fond distincts. L'ordre des prises est conservé.
- Maison en **3D native OpenGL ES 2**, avec parquet, murs, fenêtre et rideaux, plante, étagère, table et chaise, assiette et couverts, verre d'eau et lit matelassé. Éclairage et textures de bois et de tissu calculés localement.
- Huit compagnons modélisés en volume. Respiration, clignements, petits déplacements, repas à table, boisson au verre, repos au lit, joie et bouderie. Aucun compagnon ne meurt.
- Toucher l'assiette, le verre, le lit ou le compagnon ; des boutons proposent aussi ces actions. Le démarrage d'un repas demande confirmation. Les boissons respectent les pauses du planning. Le repos ne ferme pas un repas en cours.
- Collection avec aperçus, accessoires portés et ambiances installées dans la pièce. Prochains accessoires et décor du dimanche visibles, avec date et barre de progression. Un accessoire tous les deux jours ; un décor chaque dimanche suivant l'adoption. Les cadeaux restent disponibles pendant une absence et lors d'un changement de compagnon.
- L'icône dans le lanceur Android correspond au compagnon choisi. Huit alias d'activité utilisent les portraits des modèles 3D. Le nom reste **Mon Rythme Sleeve**. Le lanceur peut mettre quelques instants à actualiser l'affichage.

## Obtenir l'APK avec GitHub

1. Extraire le ZIP du projet.
2. Importer **son contenu** à la racine du dépôt : `app`, `.github`, les fichiers Gradle, etc. Le dossier `app` doit être directement à la racine, sans dossier V3 intermédiaire.
3. Dans **Actions**, lancer **Construire Mon Rythme Sleeve V3 APK** ou pousser les fichiers sur `main`.
4. Le workflow lance les tests Android puis compile l'APK.
5. Après réussite, télécharger l'artifact **MonRythmeSleeve-V3-Beta-APK**, l'extraire et installer `app-debug.apk`.

Le projet conserve l'identifiant bêta `fr.monrythmesleeve.app.beta`, avec `versionCode = 30`. Une mise à jour conservant les données exige la même signature que l'APK déjà installé. Le workflow réutilise la clé de cache V2 si elle est présente dans le même dépôt ; une clé créée dans un nouveau dépôt peut être différente. Ne pas désinstaller la version contenant des données utiles pour contourner une erreur de signature.

## Vérifications effectuées et limites

- 21 assertions exécutées sur la méthode de correction de fin extraite du Java, avec horloge et stockage simulés : recalcul à la minute supérieure, conservation du début, refus d'une fin avant le début ou dans le futur, conservation des prises suivantes et correction nocturne de l'historique.
- Rendu WebGL des méthodes de dessin du Java : génération des huit portraits, six aperçus d'accessoires, quatre ambiances et six états. Shaders compilés et rendus sans erreur WebGL ; images inspectées visuellement.
- Une suite Robolectric couvre les horaires, le calendrier des récompenses et les changements d'icône Android 28/33. **Ces tests Android n'ont pas été exécutés localement.** Ils sont inclus dans le workflow GitHub.
- **Aucun APK V3 n'a été compilé dans cette session** : JDK/SDK Android/Gradle absents, téléchargement bloqué. Un rendu de contrôle WebGL ne remplace pas un essai de l'application Android. La fluidité, le toucher et le changement d'icône doivent être vérifiés sur téléphone après compilation.

Les outils de contrôle sont dans `tools`. Le rendu local demande Node.js, Playwright et Chrome ; il relit les méthodes de dessin et les shaders de `RoomRenderer.java` pour produire les aperçus. Les contrôles Android sont dans `app/src/test`.

## Configuration

Java 17 · Gradle 8.9 · Android Gradle Plugin 8.7.3 · compileSdk 35 · minSdk 26 · targetSdk 34. Aucun moteur de jeu ni téléchargement de modèles dans l'application.
